# Directori main

> Path absolut: /FONTS/src/main

## Descripció del directori
Aquest directori conté tot el codi del projecte i els recursos per la aplicacio.

## Elements del directori

- **Directori java:**
Conté tots els codis de les classes del model classificats per directoris, un per cada capa (seguint l'arquitectura
en tres capes). El directori domini és l'únic que té contingut.

- **Directori resources:**
Conté tots els recuros necessaris per la aplicació, com arxius d'ajuda, imatges, etc.