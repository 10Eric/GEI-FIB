# Directori controladores_persistencia

> Path absolut: /FONTS/src/main/controladores_persistencia

## Descripció del directori
En aquest directori es troben totes els controladors de persistencia de les clases del nostre programa.

## Elements del directori

- **ControladorPersistenciaPrestatgeria:** Controla les dades de les prestatgerias de tots els Perfils.

- **ControladorPersistenciaPerfil:** Controla les dades dels usuaris identificats amb un usuari i una contrasenya.
