# Directori controladores

> Path absolut: /FONTS/src/main/controladores

## Descripció del directori
En aquest directori es troben totes els controladors de les clases del nostre programa.

## Elements del directori

- **ControladorProducte:** Controla la informacio del producte.

- **ControladorProducteColocat:** Controla la posicio y altura d'un producte en concret.

- **ControladorDistribucio:** Controla la distibucio de tots els ProductesColocats.

- **ControladorPerfil:** Controla els usuaris identificats amb un usuari i una contrasenya.
