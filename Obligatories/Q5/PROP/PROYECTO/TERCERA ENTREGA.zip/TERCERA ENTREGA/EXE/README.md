# Directori EXE

> Path absolut: /EXE

## Descripció del directori
Aquest directori conté tots els codis compilats del sistema. 

## Elements del directori

- **Fitxers .jar:**
Aquí es troba el fitxer .jar  TERCERA ENTREGA.jar que es el executable de l'aplicacio.


## Per ejecutar l'executable
Per ejecutar l'executable caldra fer el seguent a la terminal:
- cd a el directori /EXE
- java -jar TERCERA\ ENTREGA.jar
