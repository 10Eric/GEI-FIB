# Directori controladores_persistencia

> Path absolut: /FONTS/src/main/controladores_persistencia

## Descripció del directori
En aquest directori es troben totes els controladors de persistencia de les clases del nostre programa.

## Elements del directori

- **ControladorPersistenciaProducte:** Controla les dades de la informacio del producte.

- **ControladorPersistenciaProducteColocat:** Controla les dades de la posicio y altura d'un producte en concret.

- **ControladorPersistenciaDistribucio:** Controla les dades de la distibucio de tots els ProductesColocats.

- **ControladorPersistenciaPerfil:** Controla les dades dels usuaris identificats amb un usuari i una contrasenya.
