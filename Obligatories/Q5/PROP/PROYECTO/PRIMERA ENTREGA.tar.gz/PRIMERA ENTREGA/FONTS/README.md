# Directori FONTS

> Path absolut: /FONTS

## Descripció del directori
Aquest directori conté tot el codi del projecte organitzat per packages

## Elements del directori

- **Directori src:**
Hi ha tots els fitxers codi del sistema organitzat a partir de packages.
