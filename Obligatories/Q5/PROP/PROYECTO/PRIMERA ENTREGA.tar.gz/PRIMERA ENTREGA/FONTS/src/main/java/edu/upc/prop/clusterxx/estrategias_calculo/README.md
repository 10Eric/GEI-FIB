# Directori estrategias_calculo

> Path absolut: /FONTS/src/main/estrategias_calculo

## Descripció del directori
En aquest directori es troben els algoritmes del nostre programa.

## Elements del directori

- **CalculBackTracking:** Ejecuta l'algoritme de BackTracking

- **EstrategiaTSP:** Ejecuta l'algoritme d'aproximacio.

- **EstrategiaCalculo:** Gestiona quin algoritme s'executara.

- **EstrategiaOneToOne:** Interficie que gestiona quin algoritme s'executara.
