# Directori main

> Path absolut: /FONTS/src/main

## Descripció del directori
Aquest directori conté el codi del sistema classificat per les tres capes: domini, persistència i presentació 

## Elements del directori

- **Directori clases_dominio:**
Conté els codis de les clases de domini.

- **Directori controladores:**
Conté els codis dels controladors de les classes del projecte.

- **Directori contrladores_persistencia:**
Conté els codis de la capa de persistència.

- **Directori drivers:**
Conté els codis dels drivers del projecte.

- **Directori estrategias_calculo:**
Conté els codis dels algoritmes del projecte.
