# Directori classes

> Path absolut: /FONTS/src/main/classes_dominio

## Descripció del directori
En aquest directori es troben totes les clases de el nostre programa.

## Elements del directori

- **Producte:** Conte la informacio del producte.

- **ProducteColocat:** Conte la posicio y altura d'un producte en concret.

- **Distribucio:** Conte la distibucio de tots els ProductesColocats.

- **Perfil:** Conte els usuaris identificats amb un usuari i una contrasenya.