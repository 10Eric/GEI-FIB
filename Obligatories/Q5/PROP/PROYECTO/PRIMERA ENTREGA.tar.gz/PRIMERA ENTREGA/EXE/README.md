# Directori EXE

> Path absolut: /EXE

## Descripció del directori
Aquest directori conté tots els codis compilats del sistema juntament en els drivers. 

## Elements del directori

- **Fitxers .jar:**
Aquí es troben els fitxers .jar dels drivers una vegada compilats.

El fitxer PRIMERA ENTREGA.jar es el driver del main, que es el que te la versio mes completa, que et proba totes les funcionalitats a la vegada.

## Per ejecutar els drivers
Per ejecutar els driver caldra fer el seguent a la terminal:
- cd a el directori /EXE
- java -jar "el nombre del driver"
