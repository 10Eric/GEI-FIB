var searchData=
[
  ['cant_5fmemoria_0',['cant_memoria',['../class_proceso.html#a603846ad2cb040d55a02fb66bfed8f70',1,'Proceso']]],
  ['conexiones_1',['conexiones',['../class_cluster.html#a16419b53311b3ad41ca7b7bf16ff54ad',1,'Cluster']]]
];
