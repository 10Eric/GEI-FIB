var searchData=
[
  ['hueco_0',['hueco',['../class_procesador.html#a480911fd717866308261a6b9cf4c5e17',1,'Procesador::hueco()'],['../_procesador_8cc.html#a4275463a5b8707439866222683a2fd42',1,'hueco():&#160;Procesador.cc']]]
];
