var searchData=
[
  ['sala_5fespera_0',['Sala_Espera',['../class_sala___espera.html',1,'']]]
];
