var searchData=
[
  ['ejecutar_5fproceso_0',['ejecutar_proceso',['../class_procesador.html#a4d0cc2184305d329f0b7740a6907d7a4',1,'Procesador::ejecutar_proceso()'],['../_procesador_8cc.html#ab28acddc3dd143d971c96a09ddcdfbb9',1,'ejecutar_proceso():&#160;Procesador.cc']]],
  ['eliminar_5fproceso_1',['eliminar_proceso',['../class_procesador.html#a5dda38f6b90310926d05abf27c74ae25',1,'Procesador::eliminar_proceso()'],['../_procesador_8cc.html#afc4487cc7273d6ec7f45f8aa8bc49bd7',1,'eliminar_proceso():&#160;Procesador.cc']]],
  ['en_5fejecuccion_2',['en_ejecuccion',['../class_procesador.html#a78e27a4f0819942d344b58b1aced501f',1,'Procesador::en_ejecuccion()'],['../_procesador_8cc.html#ad6af42e1b88f8a81b19d75f90a7f5ab9',1,'en_ejecuccion():&#160;Procesador.cc']]],
  ['enviar_5fprocesos_5fcluster_3',['enviar_procesos_cluster',['../class_cluster.html#a004039bb5c853c42885e4588efa9459b',1,'Cluster::enviar_procesos_cluster()'],['../_cluster_8cc.html#ae10eddfb623d650ba66f0a5bcc6ffcf0',1,'enviar_procesos_cluster():&#160;Cluster.cc']]],
  ['espacio_4',['espacio',['../class_procesador.html#a973cb2e850d649b98a887c6b6c597b4f',1,'Procesador::espacio()'],['../_procesador_8cc.html#a940e8203f88f60be0817a9b84158e6e9',1,'espacio():&#160;Procesador.cc']]],
  ['existeix_5',['existeix',['../class_cluster.html#a8aa5e3ca55f5a6cc637b948d5ab191b5',1,'Cluster::existeix()'],['../class_procesador.html#af74a664983ca0291d735510e628323cf',1,'Procesador::existeix()'],['../_cluster_8cc.html#aec15975a74acc3add607c118601c8dfb',1,'existeix(string id_procesador):&#160;Cluster.cc'],['../_procesador_8cc.html#a6ec615b948241263533ed5051c9b2162',1,'existeix(string id_procesos):&#160;Procesador.cc']]],
  ['existeix_5fprioritat_6',['existeix_prioritat',['../class_sala___espera.html#a26966bae9e8a84150343e9c1661b806c',1,'Sala_Espera::existeix_prioritat()'],['../_sala___espera_8cc.html#ac0231123907c250000b063fffe4ac799',1,'existeix_prioritat():&#160;Sala_Espera.cc']]]
];
