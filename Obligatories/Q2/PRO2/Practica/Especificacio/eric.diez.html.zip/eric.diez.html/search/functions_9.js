var searchData=
[
  ['procesador_0',['Procesador',['../class_procesador.html#a71dbc93f54e32fa1a5c12fa8530a7f8c',1,'Procesador::Procesador()'],['../_procesador_8cc.html#a5df0fe0dd026e7092b5acbbb1f45042f',1,'Procesador():&#160;Procesador.cc']]],
  ['procesos_5fpendientes_1',['procesos_pendientes',['../class_sala___espera.html#a823dbb7992c547c6ba7ba9caa5645879',1,'Sala_Espera::procesos_pendientes()'],['../_sala___espera_8cc.html#a4324e9c45872901a0f8ad2deff7e23ba',1,'procesos_pendientes():&#160;Sala_Espera.cc']]]
];
