var searchData=
[
  ['get_5fid_0',['get_id',['../class_procesador.html#ae183223721ab79c1fee94b29711967da',1,'Procesador::get_id()'],['../_procesador_8cc.html#a1f0b8f09abd10342468ce33a1da15557',1,'get_id():&#160;Procesador.cc']]],
  ['get_5fmemoria_1',['get_memoria',['../class_procesador.html#a97eac451684c6da844dcc9d0500391c6',1,'Procesador::get_memoria()'],['../_procesador_8cc.html#aed35251c271a0152e1a40ed8bfa0b71f',1,'get_memoria():&#160;Procesador.cc']]]
];
