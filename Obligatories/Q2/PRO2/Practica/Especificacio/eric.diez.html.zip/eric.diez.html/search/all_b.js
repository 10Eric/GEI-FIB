var searchData=
[
  ['tiempo_0',['tiempo',['../class_proceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]]
];
