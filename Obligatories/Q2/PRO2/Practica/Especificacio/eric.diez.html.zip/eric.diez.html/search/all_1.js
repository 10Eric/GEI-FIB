var searchData=
[
  ['baja_5fprioridad_0',['baja_prioridad',['../class_sala___espera.html#ab76b8c1b4b8a98a9d5f492c10fe27ea3',1,'Sala_Espera::baja_prioridad()'],['../_sala___espera_8cc.html#a49a8a28e7b0697eba0e5762c589e46c7',1,'baja_prioridad():&#160;Sala_Espera.cc']]],
  ['baja_5fproceso_5fprocesador_1',['baja_proceso_procesador',['../class_cluster.html#a14a15a9e71a36c859accba9bc24a35a5',1,'Cluster::baja_proceso_procesador()'],['../_cluster_8cc.html#a86358c95099f3e79e830f29bbfead88d',1,'baja_proceso_procesador():&#160;Cluster.cc']]]
];
