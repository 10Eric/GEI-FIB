var searchData=
[
  ['memoria_0',['memoria',['../class_procesador.html#a1e4273c6277d552963355a53a4285810',1,'Procesador']]]
];
