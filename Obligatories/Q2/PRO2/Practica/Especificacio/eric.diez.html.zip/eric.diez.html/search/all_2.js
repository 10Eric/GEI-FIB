var searchData=
[
  ['cant_5fmemoria_0',['cant_memoria',['../class_proceso.html#a603846ad2cb040d55a02fb66bfed8f70',1,'Proceso']]],
  ['cluster_1',['Cluster',['../class_cluster.html',1,'']]],
  ['cluster_2ecc_2',['Cluster.cc',['../_cluster_8cc.html',1,'']]],
  ['cluster_2ehh_3',['Cluster.hh',['../_cluster_8hh.html',1,'']]],
  ['clusters_4',['Clusters',['../class_cluster.html#a40cd25533cac890b12933f214d90f2f6',1,'Cluster']]],
  ['compactar_5fmemoria_5fcluster_5',['compactar_memoria_cluster',['../class_cluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster::compactar_memoria_cluster()'],['../_cluster_8cc.html#a7985d0767446c9b3944b30b72f30dfe8',1,'compactar_memoria_cluster():&#160;Cluster.cc']]],
  ['compactar_5fmemoria_5fprocesador_6',['compactar_memoria_procesador',['../class_cluster.html#a4a776db08fb7d4542d0f073c6f94251d',1,'Cluster::compactar_memoria_procesador()'],['../_cluster_8cc.html#a440d606cc0ed382c167b716d0cd57dd6',1,'compactar_memoria_procesador():&#160;Cluster.cc']]],
  ['conexiones_7',['conexiones',['../class_cluster.html#a16419b53311b3ad41ca7b7bf16ff54ad',1,'Cluster']]],
  ['configurar_5fcluster_8',['configurar_cluster',['../class_cluster.html#a55407a5d84b8a9f1d83fc17dd198e62d',1,'Cluster']]],
  ['consultar_5fid_9',['consultar_id',['../class_proceso.html#a82739d169bede59c2574a619b5e4f999',1,'Proceso::consultar_id()'],['../_proceso_8cc.html#ae9d7996cebc7268abf5a794afedddde9',1,'consultar_id():&#160;Proceso.cc']]],
  ['consultar_5fmemoria_10',['consultar_memoria',['../class_proceso.html#ae0d3ed3fa31550cd8d74d4637c9a9b3e',1,'Proceso::consultar_memoria()'],['../_proceso_8cc.html#ad7313777adf2cba589b7833dcef0c1bc',1,'consultar_memoria():&#160;Proceso.cc']]],
  ['consultar_5fprocesos_5fenviados_11',['consultar_procesos_enviados',['../class_prioridad.html#aa7b8adc1ffc00dd4e03b4eb5884e99ef',1,'Prioridad::consultar_procesos_enviados()'],['../_prioridad_8cc.html#a736c5605999743c8f7a5088f31c62687',1,'consultar_procesos_enviados():&#160;Prioridad.cc']]],
  ['consultar_5fprocesos_5fpendientes_12',['consultar_procesos_pendientes',['../class_sala___espera.html#a91933858fe99ef1aa0cec29c8bb037e9',1,'Sala_Espera::consultar_procesos_pendientes()'],['../_sala___espera_8cc.html#a66da0ebe98770b863b764da880b14728',1,'consultar_procesos_pendientes():&#160;Sala_Espera.cc']]],
  ['consultar_5fprocesos_5frechazados_13',['consultar_procesos_rechazados',['../class_prioridad.html#ac28fac66d70dc02bba2329f4f6e41115',1,'Prioridad::consultar_procesos_rechazados()'],['../_prioridad_8cc.html#ac8086e5efb4859dbfcfbe1fa0685af1a',1,'consultar_procesos_rechazados():&#160;Prioridad.cc']]],
  ['consultar_5ftiempo_14',['consultar_tiempo',['../class_proceso.html#a4bd17f66c82490448b72c8a1afc65691',1,'Proceso::consultar_tiempo()'],['../_proceso_8cc.html#aab0ad9993e2ebcec4706e5e8e7e7d633',1,'consultar_tiempo():&#160;Proceso.cc']]]
];
