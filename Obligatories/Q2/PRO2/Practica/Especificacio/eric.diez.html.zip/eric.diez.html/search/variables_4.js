var searchData=
[
  ['pendents_0',['Pendents',['../class_sala___espera.html#a3422ab20ffba3f93004a5bcc7304c8ad',1,'Sala_Espera']]],
  ['prior_1',['Prior',['../class_sala___espera.html#a8238ddefc4bd60bfb9351dcc8170303e',1,'Sala_Espera']]],
  ['prioridades_2',['Prioridades',['../class_prioridad.html#a227e134b110237b0377fa93a5987fac0',1,'Prioridad']]],
  ['procesad_3',['Procesad',['../class_procesador.html#a0e649333dafc1bbe1a812a6d19097f3d',1,'Procesador']]]
];
