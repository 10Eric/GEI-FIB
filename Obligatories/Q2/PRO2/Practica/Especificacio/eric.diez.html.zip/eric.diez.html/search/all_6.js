var searchData=
[
  ['id_5fprioridades_0',['id_prioridades',['../class_prioridad.html#a937dc032ca98a90da28c4f6a3999bb1e',1,'Prioridad']]],
  ['id_5fprocesador_1',['id_procesador',['../class_procesador.html#ae05c442efbe50ce6cfe5d02c7dc4a1f3',1,'Procesador']]],
  ['id_5fproceso_2',['id_proceso',['../class_proceso.html#a05023cae2b605079ec2277a37d8a914e',1,'Proceso']]],
  ['imprimir_5farea_5fespera_3',['imprimir_area_espera',['../class_sala___espera.html#a9c525035de9f1f1c6ed50bc52e7a1c87',1,'Sala_Espera::imprimir_area_espera()'],['../_sala___espera_8cc.html#ac2ab2891bb2dc13ae85c97083418fc9b',1,'imprimir_area_espera():&#160;Sala_Espera.cc']]],
  ['imprimir_5festructura_5fcluster_4',['imprimir_estructura_cluster',['../class_cluster.html#a948d7075f9b30c2885ce804029e5ab25',1,'Cluster::imprimir_estructura_cluster()'],['../_cluster_8cc.html#a66397092f80950022c37032efb3da68f',1,'imprimir_estructura_cluster():&#160;Cluster.cc']]],
  ['imprimir_5fprioridad_5',['imprimir_prioridad',['../class_sala___espera.html#a7ae11794312fb62e51245f2de58aa1b9',1,'Sala_Espera::imprimir_prioridad()'],['../_sala___espera_8cc.html#aab381cb21c5e6985cfa4b7a80cdf8fb6',1,'imprimir_prioridad():&#160;Sala_Espera.cc']]],
  ['imprimir_5fprocesador_6',['imprimir_procesador',['../class_cluster.html#a419e8a28be87406b5cac78ed41f32683',1,'Cluster::imprimir_procesador()'],['../_cluster_8cc.html#a31a4c0b4c31ebdb94c28018d9af7e7d7',1,'imprimir_procesador():&#160;Cluster.cc']]],
  ['imprimir_5fprocesadores_5fcluster_7',['imprimir_procesadores_cluster',['../class_cluster.html#ab8a628286f8a977063ea4395d9a422bf',1,'Cluster::imprimir_procesadores_cluster()'],['../_cluster_8cc.html#a5c77b9a236804c610ad3c6663f87ab5c',1,'imprimir_procesadores_cluster():&#160;Cluster.cc']]],
  ['iniciar_5fsala_8',['iniciar_sala',['../class_sala___espera.html#a7dedb86d2583404fddad194c5adf4c09',1,'Sala_Espera::iniciar_sala()'],['../_sala___espera_8cc.html#a27013eeeb862b96a7147e5d6043b7a9d',1,'iniciar_sala():&#160;Sala_Espera.cc']]]
];
