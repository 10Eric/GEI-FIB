var searchData=
[
  ['id_5fprioridades_0',['id_prioridades',['../class_prioridad.html#a937dc032ca98a90da28c4f6a3999bb1e',1,'Prioridad']]],
  ['id_5fprocesador_1',['id_procesador',['../class_procesador.html#ae05c442efbe50ce6cfe5d02c7dc4a1f3',1,'Procesador']]],
  ['id_5fproceso_2',['id_proceso',['../class_proceso.html#a05023cae2b605079ec2277a37d8a914e',1,'Proceso']]]
];
