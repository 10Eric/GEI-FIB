var searchData=
[
  ['prioridad_0',['Prioridad',['../class_prioridad.html',1,'']]],
  ['procesador_1',['Procesador',['../class_procesador.html',1,'']]],
  ['proceso_2',['Proceso',['../class_proceso.html',1,'']]]
];
